-- COORDENADAS DEL CENTRO DE LA ZONA (Reemplaza los 0.0 por tus coordenadas)
local zoneCoords = vector3(-733.0463, -1251.1927, 44.7342) 
-- RADIO DE LA ZONA EN METROS
local zoneRadius = 15.0 

-- LISTA DE PROPS A ELIMINAR (Puedes añadir todos los que quieras aquí)
local modelsToDelete = {
    [GetHashKey("p_cs_sackcoal01x")] = true,
    [GetHashKey("p_cs_sackcorn01x")] = true
}

-- Función auxiliar para iterar sobre todos los objetos del juego
local function EnumerateObjects()
    return coroutine.wrap(function()
        local handle, object = FindFirstObject()
        if not handle or handle == -1 then
            EndFindObject(handle)
            return
        end
        
        local hasNext = true
        while hasNext do
            coroutine.yield(object)
            hasNext, object = FindNextObject(handle)
        end
        
        EndFindObject(handle)
    end)
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        
        local playerCoords = GetEntityCoords(PlayerPedId())
        
        -- Si el jugador está cerca
        if #(playerCoords - zoneCoords) < (zoneRadius + 50.0) then
            
            -- Recorrer TODOS los objetos que el juego tiene cargados en memoria ahora mismo
            for object in EnumerateObjects() do
                -- Si el modelo del objeto está en nuestra lista de "modelos a eliminar"
                if modelsToDelete[GetEntityModel(object)] then
                    local objCoords = GetEntityCoords(object)
                    
                    -- Si el objeto está dentro de nuestro radio de la zona
                    if #(objCoords - zoneCoords) <= zoneRadius then
                        SetEntityAsMissionEntity(object, true, true)
                        DeleteObject(object)
                        DeleteEntity(object)
                        
                        -- Forzar teletransporte al inframundo si el motor se niega a borrarlo (común en props de YMAPs)
                        if DoesEntityExist(object) then
                            SetEntityCoords(object, 0.0, 0.0, -200.0, false, false, false, false)
                            SetEntityVisible(object, false)
                        end
                    end
                end
            end
            
        else
            Citizen.Wait(3000) 
        end
    end
end)
