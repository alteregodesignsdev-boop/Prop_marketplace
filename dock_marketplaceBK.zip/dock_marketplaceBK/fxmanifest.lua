fx_version "cerulean"
game "rdr3"
rdr3_warning "I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships."

this_is_a_map "yes"

files {
    'stream/*.ytyp',
    'stream/*.ydr',
    'stream/*.ytd',
}

data_file 'DLC_ITYP_REQUEST' 'stream/*.ytyp'

client_script 'client.lua'
